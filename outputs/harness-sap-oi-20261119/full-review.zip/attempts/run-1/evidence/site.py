"""Loopback-only fictional SAP UI. Exports come from browser DOM interaction."""

import argparse
import json
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).resolve().parent
HTML = """<!doctype html><html lang="zh-Hant"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>模擬 SAP OI</title>
<style>
:root{--foreground:#17263b;--card:#fff;--secondary:#edf2f7;--border:#d5dce5;--primary:#1665a8;--muted-foreground:#58687d;--radius:10px;--font-sans:Arial,sans-serif}
body{margin:0;color:var(--foreground);font:14px var(--font-sans);background:transparent}
header{padding:18px 0;border-bottom:2px solid var(--primary)}h1{font-size:22px;margin:0 0 6px}p{line-height:1.6;margin:6px 0;color:var(--muted-foreground)}
main{max-width:1250px;margin:auto}form{display:flex;flex-wrap:wrap;gap:14px;align-items:end;padding:20px 0}
label{display:flex;flex-direction:column;gap:7px;font-weight:600}input{border:1px solid var(--border);padding:10px;border-radius:6px;background:var(--card);color:var(--foreground)}
#sales{width:285px}button{padding:10px 15px;border:1px solid var(--border);border-radius:6px;background:var(--card);color:var(--foreground);cursor:pointer}button.primary{background:var(--primary);color:white;border-color:var(--primary)}button:disabled{opacity:.45;cursor:default}
.toolbar{display:flex;gap:12px;align-items:center;justify-content:space-between;padding:12px 0}.table-wrap{overflow:auto;border:1px solid var(--border);border-radius:var(--radius)}
table{border-collapse:collapse;width:100%;white-space:nowrap}th,td{padding:12px;text-align:left;border-bottom:1px solid var(--border)}th{background:var(--secondary);font-size:12px}td:last-child{text-align:right;font-variant-numeric:tabular-nums}tbody tr:nth-child(even){background:var(--secondary)}
.pager{display:flex;gap:12px;align-items:center;justify-content:flex-end;padding:16px 0}.tag{font-size:12px;background:var(--secondary);padding:5px 9px;border-radius:4px}.note{margin-top:10px}#error{color:#b42318}
</style><main><header><h1>模擬 SAP OI 記錄</h1><p>虛構測試資料。日期時區 Asia/Taipei。網頁篩選後仍須依 SOP 排除無效狀態與重複列。</p></header>
<form id="filters"><label for="start">Start date<input id="start" type="date" value="2026-09-01" required></label><label for="end">End date<input id="end" type="date" value="2026-10-31" required></label><label for="sales">Sales<input id="sales" placeholder="姓名，以逗號分隔；空白代表全部"></label><button class="primary" type="submit">Search</button></form>
<div id="error" role="alert"></div><div class="toolbar"><strong id="count" role="status"></strong><button id="export" type="button">Export all filtered CSV</button></div>
<div class="table-wrap"><table id="oi-table"><caption style="text-align:left;padding:10px">OI records — current page</caption><thead><tr></tr></thead><tbody></tbody></table></div>
<div class="pager"><span id="page-info"></span><button id="previous" type="button">Previous</button><button id="next" type="button">Next</button></div>
<p class="note">每頁 5 筆。Export all filtered CSV 會匯出所有篩選結果，包括其他頁面的資料。OI Amount 是原幣金額，並非統一幣別總額。</p><span class="tag">Simulation only — no company SAP connection</span></main>
<script>
const RECORDS=__RECORDS__;
const columns=[['document','OI Document'],['line','Line'],['created_at','CreatedAt'],['sales','Sales'],['customer','Customer'],['status','Status'],['currency','Currency'],['amount','OI Amount']];
let selected=[...RECORDS],page=0;const size=5;
const header=document.querySelector('thead tr');for(const [,label] of columns){const th=document.createElement('th');th.textContent=label;header.append(th)}
function draw(){const body=document.querySelector('tbody');body.replaceChildren();for(const row of selected.slice(page*size,(page+1)*size)){const tr=document.createElement('tr');for(const [key] of columns){const td=document.createElement('td');td.textContent=key==='amount'?Number(row[key]).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}):row[key];tr.append(td)}body.append(tr)}
document.getElementById('count').textContent=`${selected.length} filtered records`;
document.getElementById('page-info').textContent=`Page ${page+1} of ${Math.max(1,Math.ceil(selected.length/size))}`;
document.getElementById('previous').disabled=page===0;document.getElementById('next').disabled=(page+1)*size>=selected.length;}
document.getElementById('filters').addEventListener('submit',e=>{e.preventDefault();const start=document.getElementById('start').value,end=document.getElementById('end').value;const sales=document.getElementById('sales').value.split(',').map(x=>x.trim()).filter(Boolean);if(start>end){document.getElementById('error').textContent='Start date must not exceed End date';return}document.getElementById('error').textContent='';selected=RECORDS.filter(r=>r.created_at.slice(0,10)>=start&&r.created_at.slice(0,10)<=end&&(!sales.length||sales.includes(r.sales)));page=0;draw()});
document.getElementById('previous').onclick=()=>{page--;draw()};document.getElementById('next').onclick=()=>{page++;draw()};
document.getElementById('export').onclick=()=>{const quote=x=>'"'+String(x).replaceAll('"','""')+'"';const csv=[columns.map(x=>x[1]),...selected.map(r=>columns.map(([key])=>r[key]))].map(r=>r.map(quote).join(',')).join('\\r\\n');const url=URL.createObjectURL(new Blob(['\\ufeff'+csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='sap-oi-filtered.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)};draw();
</script></html>"""


def make_page(destination: Path) -> Path:
    destination.mkdir(parents=True, exist_ok=True)
    records = json.loads((HERE / "fixtures/records.json").read_text(encoding="utf-8"))
    page = destination / "index.html"
    page.write_text(HTML.replace("__RECORDS__", json.dumps(records)), encoding="utf-8")
    return page


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--directory", type=Path, required=True)
    parser.add_argument("--port", type=int, default=8766)
    args = parser.parse_args()
    make_page(args.directory)
    handler = partial(SimpleHTTPRequestHandler, directory=str(args.directory.resolve()))
    with ThreadingHTTPServer(("127.0.0.1", args.port), handler) as server:
        print(f"http://127.0.0.1:{server.server_port}", flush=True)
        server.serve_forever()


if __name__ == "__main__":
    main()
