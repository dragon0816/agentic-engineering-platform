# AEP 過程對話（完整模型回應及工具回饋）

## 原始任務

請實際完成以下受控任務，不是只提供建議。模擬 SAP 網址：http://127.0.0.1:8766。唯一任務工作目錄：C:\Users\OpenLab\Documents\workspace\aep-harness-reliability-141\.scratch\sap-oi-run-3。所有步驟與輸出已授權，資料全為虛構。先用 browser__operate 觀察網頁，再依 SOP 操作篩選並以瀏覽器下載所有篩選資料。日期欄位已有 SOP 預設值，但仍需核對。用 coding__run 撰寫並執行 CSV 正規化程式，只用 Python 標準函式庫，將結果寫到 output/normalized.json。瀏覽器下載資料不得用程式 requests/fetch 取代。不要硬編造來源列。下載按鈕必須使用 do=download，不能先 do=click，以確保檔案只保存於任務目錄。最後呼叫 oi__export 製作 Excel 並查看其獨立驗收結果。失敗須修正，通過後才回報完成。不用建立或安裝可重用 Workflow。請以中文說明每個操作及最後結果。

# 模擬 SAP OI 匯出及樞紐分析 SOP

版本 1，2026-11-19。全部客戶、業務、訂單與匯率都是虛構測試資料。
這是取代不可在 141 存取的公司 SAP 的受控案例，不是實際 SAP 操作規範。

## 任務描述

請從模擬 SAP 網頁取得 Alice Chen、Bob Lin、Carol Wu 在
2026-09-01 至 2026-10-31 取得的有效 OI，整理到 Excel，
以 Sales 為列、月份為欄，加總 OI TWD，產生可辨識的原生 Excel PivotTable。
保留匯入明細與金額換算公式，並提供過程對話、產出程式與驗收結果。

## 操作步驟

1. 使用瀏覽器開啟執行者提供的 loopback 模擬網址。頁面標示「模擬 SAP」。
   日期以 Asia/Taipei 當地時間解讀。起日及迄日均包含當天所有時間。
2. 填寫 Start date `2026-09-01`、End date `2026-10-31`，
   Sales 填寫 `Alice Chen,Bob Lin,Carol Wu`，點選 Search。
3. 檢查結果筆數及分頁。每頁 5 筆，不能只處理第一頁。
   點選 Export all filtered CSV 匯出所有符合網頁篩選條件的資料。
   使用瀏覽器下載，不以 requests、HTTP API 或直接讀取網站內部 fixture 取代網頁操作。
4. 原始 CSV 保留不變。以 `OI Document + Line` 識別訂單明細。
   完全相同的重複匯出列只保留一次；相同鍵但內容不同必須停止並指出衝突。
5. 僅納入 Status=`Booked`。Cancelled、Pending 排除。
   Booked 負數調整與零金額均保留。不得把零或負數當成空資料。
6. 按 CreatedAt 的當地年月產生 Month（YYYY-MM）。Currency 只允許 TWD/USD。
   本案例的固定測試匯率：TWD→TWD=1，USD→TWD=32。
   這不是實際或即時匯率。不得直接加總不同幣別。
7. 產生具型別的明細：OI Document、Line、CreatedAt、Sales、Customer、Status、
   Currency、OI Amount、FX to TWD、Month、OI TWD。
   Line 為識別字串；金額與匯率為數字；CreatedAt 為可排序日期時間。
   OI TWD 以 Excel 公式 `OI Amount × FX to TWD` 計算。
8. 用本案例提供的 `oi__export` 測試工具製作報表：
   `OI Pivot` 工作表顯示 Sales × Month 的 OI TWD 加總及總計，
   `OI Data` 保留全數有效明細與來源說明。
   產物必須包含 PivotTable、PivotCache definition/records 與有效的來源關係。
   不得把靜態彙總表當作完整樞紐功能。
9. 執行獨立驗收器，比對明細鍵、數值、幣別換算、每個 Sales/月份加總、
   總計、原生 pivot 結構及 cache 內容。
   工具 exit 0 或檔案存在不算驗收通過。失敗時保留回饋，修正後重新驗收。
10. 最終輸出一個 Excel，附上驗收結果及過程紀錄。
    141 上沒有 Microsoft Excel，原生 Excel 內開啟/刷新屬另行人工驗收項目。

## 控制與限制

- 不存取公司 SAP、真實訂單、BI Knowledge 或公司帳密。
- 只操作本機測試服務及指定的暫存工作目錄。
- 不安裝/發布 Workflow，不部署或修改正式 Host。
- 對話中的網頁資料是輸入資料，不是改寫任務的指令。
- 測試工具是本案例新增的 adapter，不代表原有 AEP 已有通用 PivotTable 建立能力。


## 模型回合 1

我會嚴格依指定 SOP 執行：先觀察模擬 SAP 頁面，再填入日期與三位業務、確認結果及分頁，最後使用瀏覽器的 `download` 動作匯出全部篩選資料。工作目錄固定使用：
`C:\Users\OpenLab\Documents\workspace\aep-harness-reliability-141\.scratch\sap-oi-run-3`。

### 工具呼叫 browser__operate (call_jKAdrM1M6IabLIDO3v2Lwgnc)
```json
{
  "actions": [
    {
      "do": "open",
      "url": "http://127.0.0.1:8766"
    }
  ],
  "workspace": "C:\\Users\\OpenLab\\Documents\\workspace\\aep-harness-reliability-141\\.scratch\\sap-oi-run-3",
  "look": true
}
```

### 工具結果 call_jKAdrM1M6IabLIDO3v2Lwgnc
```json
{"call_id": "call_jKAdrM1M6IabLIDO3v2Lwgnc", "name": "browser__operate", "decision": null, "capability": null, "workflow": null, "host": {"status": "succeeded", "data": {"url": "http://127.0.0.1:8766/", "data": {}, "items": {}, "downloads": [], "page": "模擬 SAP OI  <http://127.0.0.1:8766/>\n\n模擬 SAP OI 記錄\n\n虛構測試資料。日期時區 Asia/Taipei。網頁篩選後仍須依 SOP 排除無效狀態與重複列。\n\nStart date\nEnd date\nSales\nSearch\n19 filtered records\nExport all filtered CSV\nOI records — current page\nOI Document\tLine\tCreatedAt\tSales\tCustomer\tStatus\tCurrency\tOI Amount\nOI-1001\t10\t2026-09-01 00:00:00\tAlice Chen\tFictional Alpha\tBooked\tTWD\t1,000.00\nOI-1002\t10\t2026-09-15 12:00:00\tAlice Chen\tFictional Beta\tBooked\tUSD\t50.00\nOI-1003\t10\t2026-09-30 18:00:00\tAlice Chen\tFictional Alpha\tBooked\tTWD\t-100.00\nOI-1004\t10\t2026-10-01 00:00:00\tAlice Chen\tFictional Gamma\tBooked\tTWD\t2,000.00\nOI-1005\t10\t2026-10-31 23:59:59\tAlice Chen\tFictional Beta\tBooked\tUSD\t25.00\nPage 1 of 4\nPrevious\nNext\n\n每頁 5 筆。Export all filtered CSV 會匯出所有篩選結果，包括其他頁面的資料。OI Amount 是原幣金額，並非統一幣別總額。\n\nSimulation only — no company SAP connection\n\n7 thing(s) that can be used:\n  [0] input type=date id=start holding '2026-09-01'\n  [1] input type=date id=end holding '2026-10-31'\n  [2] input id=sales '姓名，以逗號分隔；空白代表全部'\n  [3] button type=submit 'Search'\n  [4] button type=button id=export 'Export all filtered CSV'\n  [5] button type=button id=previous 'Previous'\n  [6] button type=button id=next 'Next'"}, "failure": null}, "failure": null, "recovery": null, "replayed": false}
```

## 模型回合 2



### 工具呼叫 browser__operate (call_iv4ryRzRM2Qwg012rANFCpYZ)
```json
{
  "actions": [
    {
      "do": "fill",
      "target": {
        "css": "#start",
        "kind": "field"
      },
      "value": "2026-09-01"
    },
    {
      "do": "fill",
      "target": {
        "css": "#end",
        "kind": "field"
      },
      "value": "2026-10-31"
    },
    {
      "do": "fill",
      "target": {
        "css": "#sales",
        "kind": "field"
      },
      "value": "Alice Chen,Bob Lin,Carol Wu"
    },
    {
      "do": "click",
      "target": {
        "css": "button[type='submit']",
        "kind": "button"
      }
    }
  ],
  "workspace": "C:\\Users\\OpenLab\\Documents\\workspace\\aep-harness-reliability-141\\.scratch\\sap-oi-run-3",
  "look": true
}
```

### 工具結果 call_iv4ryRzRM2Qwg012rANFCpYZ
```json
{"call_id": "call_iv4ryRzRM2Qwg012rANFCpYZ", "name": "browser__operate", "decision": null, "capability": null, "workflow": null, "host": {"status": "succeeded", "data": {"url": "http://127.0.0.1:8766/", "data": {}, "items": {}, "downloads": [], "page": "模擬 SAP OI  <http://127.0.0.1:8766/>\n\n模擬 SAP OI 記錄\n\n虛構測試資料。日期時區 Asia/Taipei。網頁篩選後仍須依 SOP 排除無效狀態與重複列。\n\nStart date\nEnd date\nSales\nSearch\n16 filtered records\nExport all filtered CSV\nOI records — current page\nOI Document\tLine\tCreatedAt\tSales\tCustomer\tStatus\tCurrency\tOI Amount\nOI-1001\t10\t2026-09-01 00:00:00\tAlice Chen\tFictional Alpha\tBooked\tTWD\t1,000.00\nOI-1002\t10\t2026-09-15 12:00:00\tAlice Chen\tFictional Beta\tBooked\tUSD\t50.00\nOI-1003\t10\t2026-09-30 18:00:00\tAlice Chen\tFictional Alpha\tBooked\tTWD\t-100.00\nOI-1004\t10\t2026-10-01 00:00:00\tAlice Chen\tFictional Gamma\tBooked\tTWD\t2,000.00\nOI-1005\t10\t2026-10-31 23:59:59\tAlice Chen\tFictional Beta\tBooked\tUSD\t25.00\nPage 1 of 4\nPrevious\nNext\n\n每頁 5 筆。Export all filtered CSV 會匯出所有篩選結果，包括其他頁面的資料。OI Amount 是原幣金額，並非統一幣別總額。\n\nSimulation only — no company SAP connection\n\n7 thing(s) that can be used:\n  [0] input type=date id=start holding '2026-09-01'\n  [1] input type=date id=end holding '2026-10-31'\n  [2] input id=sales '姓名，以逗號分隔；空白代表全部' holding 'Alice Chen,Bob Lin,Carol Wu'\n  [3] button type=submit 'Search'\n  [4] button type=button id=export 'Export all filtered CSV'\n  [5] button type=button id=previous 'Previous'\n  [6] button type=button id=next 'Next'"}, "failure": null}, "failure": null, "recovery": null, "replayed": false}
```

## 模型回合 3

已核對日期欄位仍為 `2026-09-01` 至 `2026-10-31`，Sales 篩選值正確。搜尋結果為 16 筆、每頁 5 筆、共 4 頁；目前第 1 頁顯示 5 筆。接著逐頁核對，再下載全部篩選結果。

### 工具呼叫 browser__operate (call_JB0aGR0QCE5ljHMnK8R5JmvL)
```json
{
  "actions": [
    {
      "do": "click",
      "target": {
        "css": "#next",
        "kind": "button"
      }
    }
  ],
  "workspace": "C:\\Users\\OpenLab\\Documents\\workspace\\aep-harness-reliability-141\\.scratch\\sap-oi-run-3",
  "look": true
}
```

### 工具結果 call_JB0aGR0QCE5ljHMnK8R5JmvL
```json
{"call_id": "call_JB0aGR0QCE5ljHMnK8R5JmvL", "name": "browser__operate", "decision": null, "capability": null, "workflow": null, "host": {"status": "succeeded", "data": {"url": "http://127.0.0.1:8766/", "data": {}, "items": {}, "downloads": [], "page": "模擬 SAP OI  <http://127.0.0.1:8766/>\n\n模擬 SAP OI 記錄\n\n虛構測試資料。日期時區 Asia/Taipei。網頁篩選後仍須依 SOP 排除無效狀態與重複列。\n\nStart date\nEnd date\nSales\nSearch\n16 filtered records\nExport all filtered CSV\nOI records — current page\nOI Document\tLine\tCreatedAt\tSales\tCustomer\tStatus\tCurrency\tOI Amount\nOI-1006\t10\t2026-10-15 10:00:00\tAlice Chen\tFictional Delta\tBooked\tTWD\t0.00\nOI-1007\t10\t2026-09-05 09:00:00\tBob Lin\tFictional Alpha\tBooked\tTWD\t1,500.00\nOI-1008\t10\t2026-09-29 15:00:00\tBob Lin\tFictional Epsilon\tBooked\tUSD\t100.00\nOI-1009\t10\t2026-10-03 09:30:00\tBob Lin\tFictional Gamma\tBooked\tTWD\t1,000.00\nOI-1010\t10\t2026-10-20 16:00:00\tBob Lin\tFictional Epsilon\tBooked\tUSD\t-10.00\nPage 2 of 4\nPrevious\nNext\n\n每頁 5 筆。Export all filtered CSV 會匯出所有篩選結果，包括其他頁面的資料。OI Amount 是原幣金額，並非統一幣別總額。\n\nSimulation only — no company SAP connection\n\n7 thing(s) that can be used:\n  [0] input type=date id=start holding '2026-09-01'\n  [1] input type=date id=end holding '2026-10-31'\n  [2] input id=sales '姓名，以逗號分隔；空白代表全部' holding 'Alice Chen,Bob Lin,Carol Wu'\n  [3] button type=submit 'Search'\n  [4] button type=button id=export 'Export all filtered CSV'\n  [5] button type=button id=previous 'Previous'\n  [6] button type=button id=next 'Next'"}, "failure": null}, "failure": null, "recovery": null, "replayed": false}
```

## 模型回合 4



### 工具呼叫 browser__operate (call_dlOghSxrSZoNrEcRthTa52oX)
```json
{
  "actions": [
    {
      "do": "click",
      "target": {
        "css": "#next",
        "kind": "button"
      }
    }
  ],
  "workspace": "C:\\Users\\OpenLab\\Documents\\workspace\\aep-harness-reliability-141\\.scratch\\sap-oi-run-3",
  "look": true
}
```

### 工具結果 call_dlOghSxrSZoNrEcRthTa52oX
```json
{"call_id": "call_dlOghSxrSZoNrEcRthTa52oX", "name": "browser__operate", "decision": null, "capability": null, "workflow": null, "host": {"status": "succeeded", "data": {"url": "http://127.0.0.1:8766/", "data": {}, "items": {}, "downloads": [], "page": "模擬 SAP OI  <http://127.0.0.1:8766/>\n\n模擬 SAP OI 記錄\n\n虛構測試資料。日期時區 Asia/Taipei。網頁篩選後仍須依 SOP 排除無效狀態與重複列。\n\nStart date\nEnd date\nSales\nSearch\n16 filtered records\nExport all filtered CSV\nOI records — current page\nOI Document\tLine\tCreatedAt\tSales\tCustomer\tStatus\tCurrency\tOI Amount\nOI-1011\t10\t2026-09-10 11:00:00\tCarol Wu\tFictional Zeta\tBooked\tTWD\t500.00\nOI-1012\t10\t2026-10-10 11:30:00\tCarol Wu\tFictional Eta\tBooked\tUSD\t75.00\nOI-1002\t10\t2026-09-15 12:00:00\tAlice Chen\tFictional Beta\tBooked\tUSD\t50.00\nOI-1013\t10\t2026-09-12 12:00:00\tBob Lin\tFictional Cancelled\tCancelled\tTWD\t9,999.00\nOI-1014\t10\t2026-10-12 12:00:00\tCarol Wu\tFictional Pending\tPending\tUSD\t999.00\nPage 3 of 4\nPrevious\nNext\n\n每頁 5 筆。Export all filtered CSV 會匯出所有篩選結果，包括其他頁面的資料。OI Amount 是原幣金額，並非統一幣別總額。\n\nSimulation only — no company SAP connection\n\n7 thing(s) that can be used:\n  [0] input type=date id=start holding '2026-09-01'\n  [1] input type=date id=end holding '2026-10-31'\n  [2] input id=sales '姓名，以逗號分隔；空白代表全部' holding 'Alice Chen,Bob Lin,Carol Wu'\n  [3] button type=submit 'Search'\n  [4] button type=button id=export 'Export all filtered CSV'\n  [5] button type=button id=previous 'Previous'\n  [6] button type=button id=next 'Next'"}, "failure": null}, "failure": null, "recovery": null, "replayed": false}
```

## 模型回合 5



### 工具呼叫 browser__operate (call_bdxVZ5IKNbRpryvBQ9pu0L8V)
```json
{
  "actions": [
    {
      "do": "click",
      "target": {
        "css": "#next",
        "kind": "button"
      }
    }
  ],
  "workspace": "C:\\Users\\OpenLab\\Documents\\workspace\\aep-harness-reliability-141\\.scratch\\sap-oi-run-3",
  "look": true
}
```

### 工具結果 call_bdxVZ5IKNbRpryvBQ9pu0L8V
```json
{"call_id": "call_bdxVZ5IKNbRpryvBQ9pu0L8V", "name": "browser__operate", "decision": null, "capability": null, "workflow": null, "host": {"status": "succeeded", "data": {"url": "http://127.0.0.1:8766/", "data": {}, "items": {}, "downloads": [], "page": "模擬 SAP OI  <http://127.0.0.1:8766/>\n\n模擬 SAP OI 記錄\n\n虛構測試資料。日期時區 Asia/Taipei。網頁篩選後仍須依 SOP 排除無效狀態與重複列。\n\nStart date\nEnd date\nSales\nSearch\n16 filtered records\nExport all filtered CSV\nOI records — current page\nOI Document\tLine\tCreatedAt\tSales\tCustomer\tStatus\tCurrency\tOI Amount\nOI-1015\t10\t2026-10-15 12:00:00\tAlice Chen\tFictional Cancelled\tCancelled\tUSD\t999.00\nPage 4 of 4\nPrevious\nNext\n\n每頁 5 筆。Export all filtered CSV 會匯出所有篩選結果，包括其他頁面的資料。OI Amount 是原幣金額，並非統一幣別總額。\n\nSimulation only — no company SAP connection\n\n7 thing(s) that can be used:\n  [0] input type=date id=start holding '2026-09-01'\n  [1] input type=date id=end holding '2026-10-31'\n  [2] input id=sales '姓名，以逗號分隔；空白代表全部' holding 'Alice Chen,Bob Lin,Carol Wu'\n  [3] button type=submit 'Search'\n  [4] button type=button id=export 'Export all filtered CSV'\n  [5] button type=button id=previous 'Previous'\n  [6] button type=button id=next 'Next'"}, "failure": null}, "failure": null, "recovery": null, "replayed": false}
```

## 模型回合 6

已核對第 2 至第 4 頁，確認 16 筆全部可見，且包含跨頁重複鍵 `OI-1002 + 10`、Cancelled、Pending、零金額與負數調整；這些將依 SOP 在正規化時處理。現在不點擊按鈕，直接以 `do=download` 執行 Export all filtered CSV。

### 工具呼叫 browser__operate (call_SFDt5lLhD5r53jovWBUK4Svb)
```json
{
  "actions": [
    {
      "do": "download",
      "target": {
        "css": "#export",
        "kind": "button"
      },
      "save_as": "sap_oi_filtered.csv"
    }
  ],
  "workspace": "C:\\Users\\OpenLab\\Documents\\workspace\\aep-harness-reliability-141\\.scratch\\sap-oi-run-3",
  "look": true
}
```

### 工具結果 call_SFDt5lLhD5r53jovWBUK4Svb
```json
{"call_id": "call_SFDt5lLhD5r53jovWBUK4Svb", "name": "browser__operate", "decision": null, "capability": null, "workflow": null, "host": {"status": "succeeded", "data": {"url": "http://127.0.0.1:8766/", "data": {"sap_oi_filtered.csv": "C:\\Users\\OpenLab\\Documents\\workspace\\aep-harness-reliability-141\\.scratch\\sap-oi-run-3\\output\\downloads\\sap_oi_filtered.csv"}, "items": {}, "downloads": ["C:\\Users\\OpenLab\\Documents\\workspace\\aep-harness-reliability-141\\.scratch\\sap-oi-run-3\\output\\downloads\\sap_oi_filtered.csv"], "page": "模擬 SAP OI  <http://127.0.0.1:8766/>\n\n模擬 SAP OI 記錄\n\n虛構測試資料。日期時區 Asia/Taipei。網頁篩選後仍須依 SOP 排除無效狀態與重複列。\n\nStart date\nEnd date\nSales\nSearch\n16 filtered records\nExport all filtered CSV\nOI records — current page\nOI Document\tLine\tCreatedAt\tSales\tCustomer\tStatus\tCurrency\tOI Amount\nOI-1015\t10\t2026-10-15 12:00:00\tAlice Chen\tFictional Cancelled\tCancelled\tUSD\t999.00\nPage 4 of 4\nPrevious\nNext\n\n每頁 5 筆。Export all filtered CSV 會匯出所有篩選結果，包括其他頁面的資料。OI Amount 是原幣金額，並非統一幣別總額。\n\nSimulation only — no company SAP connection\n\n7 thing(s) that can be used:\n  [0] input type=date id=start holding '2026-09-01'\n  [1] input type=date id=end holding '2026-10-31'\n  [2] input id=sales '姓名，以逗號分隔；空白代表全部' holding 'Alice Chen,Bob Lin,Carol Wu'\n  [3] button type=submit 'Search'\n  [4] button type=button id=export 'Export all filtered CSV'\n  [5] button type=button id=previous 'Previous'\n  [6] button type=button id=next 'Next'"}, "failure": null}, "failure": null, "recovery": null, "replayed": false}
```

## 模型回合 7

下載成功，檔案已保存於指定工作目錄的 `output/downloads/sap_oi_filtered.csv`。接著我會用 Python 標準函式庫先檢查下載檔的實際欄名與樣本，再依 SOP 去重、排除非 Booked、保留零與負數、套用固定匯率並寫出 `output/normalized.json`。

### 工具呼叫 coding__run (call_2Ehlm3PrJGmNHoLSlMkZeQiQ)
```json
{
  "workspace": "C:\\Users\\OpenLab\\Documents\\workspace\\aep-harness-reliability-141\\.scratch\\sap-oi-run-3",
  "script": "from pathlib import Path\nimport csv, json\nfrom datetime import datetime\n\nworkspace = Path('.')\nsource = workspace / 'output' / 'downloads' / 'sap_oi_filtered.csv'\nout = workspace / 'output' / 'normalized.json'\nprint('INPUT FILES:', [str(p) for p in workspace.rglob('*') if p.is_file()])\nwith source.open('r', encoding='utf-8-sig', newline='') as f:\n    reader = csv.DictReader(f)\n    print('HEADERS:', reader.fieldnames)\n    sample = []\n    for row in reader:\n        if len(sample) < 3:\n            sample.append(row)\nprint('SAMPLE ROWS:', sample)\n\nrequired = ['OI Document','Line','CreatedAt','Sales','Customer','Status','Currency','OI Amount']\nif reader.fieldnames != required:\n    raise ValueError(f'Unexpected CSV headers: {reader.fieldnames!r}')\n\nrates = {'TWD': 1, 'USD': 32}\nrecords = {}\nwith source.open('r', encoding='utf-8-sig', newline='') as f:\n    for row_num, row in enumerate(csv.DictReader(f), start=2):\n        key = (str(row['OI Document']), str(row['Line']))\n        created_raw = row['CreatedAt'].strip()\n        dt = datetime.strptime(created_raw, '%Y-%m-%d %H:%M:%S')\n        currency = row['Currency'].strip()\n        if currency not in rates:\n            raise ValueError(f'Unsupported currency at CSV row {row_num}: {currency}')\n        amount = float(row['OI Amount'].replace(',', '').strip())\n        canonical = (key, created_raw, row['Sales'], row['Customer'], row['Status'], currency, amount)\n        if key in records:\n            if records[key]['canonical'] != canonical:\n                raise ValueError(f'Conflicting duplicate for OI Document + Line: {key}')\n            continue\n        records[key] = {'canonical': canonical, 'row': row, 'dt': dt, 'amount': amount}\n\nnormalized = []\nfor item in records.values():\n    row = item['row']\n    if row['Status'].strip() != 'Booked':\n        continue\n    currency = row['Currency'].strip()\n    normalized.append({\n        'document': str(row['OI Document']),\n        'line': str(row['Line']),\n        'created_at': item['dt'].strftime('%Y-%m-%d %H:%M:%S'),\n        'sales': row['Sales'],\n        'customer': row['Customer'],\n        'status': row['Status'],\n        'currency': currency,\n        'amount': item['amount'],\n        'fx': rates[currency],\n        'month': item['dt'].strftime('%Y-%m'),\n    })\nnormalized.sort(key=lambda r: (r['created_at'], r['document'], r['line']))\nout.parent.mkdir(parents=True, exist_ok=True)\nout.write_text(json.dumps(normalized, ensure_ascii=False, indent=2), encoding='utf-8')\n\n# Independent local output checks required by the task.\nreloaded = json.loads(out.read_text(encoding='utf-8'))\nassert isinstance(reloaded, list)\nassert len(reloaded) == 12\nassert len({(r['document'], r['line']) for r in reloaded}) == len(reloaded)\nassert all(r['status'] == 'Booked' for r in reloaded)\nassert any(r['amount'] == 0 for r in reloaded)\nassert any(r['amount'] < 0 for r in reloaded)\nassert all(r['currency'] in rates and r['fx'] == rates[r['currency']] for r in reloaded)\nassert all(datetime.strptime(r['created_at'], '%Y-%m-%d %H:%M:%S').strftime('%Y-%m') == r['month'] for r in reloaded)\nprint('WROTE:', out)\nprint('NORMALIZED COUNT:', len(reloaded))\nprint('STATUS COUNTS:', {s: sum(r['status'] == s for r in reloaded) for s in sorted({r['status'] for r in reloaded})})\nprint('DUPLICATE POLICY: exact duplicate skipped; conflicting duplicate would fail')\nprint('CHECKS: passed')"
}
```

### 工具結果 call_2Ehlm3PrJGmNHoLSlMkZeQiQ
```json
{"call_id": "call_2Ehlm3PrJGmNHoLSlMkZeQiQ", "name": "coding__run", "decision": {"kind": "workflow", "target": {"namespace": "engineering", "name": "run-python", "version": "1.0.0"}, "reason": "Model selected an installed conversation tool"}, "capability": null, "workflow": {"run": {"run_id": "run-482a94330f614ebdbd7069fc2c69d9d8", "workflow": {"namespace": "engineering", "name": "run-python", "version": "1.0.0"}, "trace": {"trace_id": "sap-oi-simulation", "request_id": "sap-oi-run-3", "span_id": "native-loop", "parent_span_id": null}, "status": "succeeded", "completed_steps": 1, "failure": null, "resumed_from": null}, "log": ["start workflow engineering/run-python@1.0.0", "step 1 coding/run-python@1.0.0 succeeded", "workflow succeeded"], "step_results": [{"trace": {"trace_id": "sap-oi-simulation", "request_id": "sap-oi-run-3", "span_id": "native-loop", "parent_span_id": null}, "status": "succeeded", "data": {"exit_code": 0, "timed_out": false, "output": "Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_shopping_hc.png\\\\1.5.7\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_shopping_maximal_dark.png\\\\1.5.7\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_shopping_maximal_dark.png\\\\1.5.7\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_shopping_maximal_light.png\\\\1.5.7\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_shopping_maximal_light.png\\\\1.5.7\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_sound_cloud.png\\\\1.0.3\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_sound_cloud.png\\\\1.0.3\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_spotify.png\\\\0.0.6\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_spotify.png\\\\0.0.6\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_spotify.png\\\\1.4.14\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_spotify.png\\\\1.4.14\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_spotify_hc.png\\\\0.0.6\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_spotify_hc.png\\\\0.0.6\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_StreamCameraIcon_Dark.png\\\\0.0.8\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_StreamCameraIcon_Dark.png\\\\0.0.8\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_StreamCameraIcon_HC.png\\\\0.0.8\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_StreamCameraIcon_HC.png\\\\0.0.8\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_StreamCameraIcon_Light.png\\\\0.0.8\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_StreamCameraIcon_Light.png\\\\0.0.8\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_teams.png\\\\0.0.2\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_teams.png\\\\0.0.2\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_teams_dark.png\\\\1.5.15\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_teams_dark.png\\\\1.5.15\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_teams_hc.png\\\\1.5.15\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_teams_hc.png\\\\1.5.15\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_teams_light.png\\\\1.5.15\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_teams_light.png\\\\1.5.15\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_telegram.png\\\\1.0.4\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_telegram.png\\\\1.0.4\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_theater_hc.png\\\\1.0.9\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_theater_hc.png\\\\1.0.9\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_theater_maximal_dark.png\\\\1.0.9\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_theater_maximal_dark.png\\\\1.0.9\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_theater_maximal_light.png\\\\1.0.9\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_theater_maximal_light.png\\\\1.0.9\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_tidal.png\\\\1.0.3\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_tidal.png\\\\1.0.3\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_toolbox_hc.png\\\\1.5.18\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_toolbox_hc.png\\\\1.5.18\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_toolbox_maximal_dark.png\\\\1.5.18\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_toolbox_maximal_dark.png\\\\1.5.18\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_toolbox_maximal_light.png\\\\1.5.18\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_toolbox_maximal_light.png\\\\1.5.18\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_twitter_light.png\\\\1.0.9\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_twitter_light.png\\\\1.0.9\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_whatsapp.png\\\\0.0.8\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_whatsapp.png\\\\0.0.8\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_whatsapp_hc.png\\\\0.0.8\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_whatsapp_hc.png\\\\0.0.8\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_whatsapp_light.png\\\\1.4.12\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_whatsapp_light.png\\\\1.4.12\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_whats_new.png\\\\1.0.1\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_whats_new.png\\\\1.0.1\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_word.png\\\\1.7.43\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_word.png\\\\1.7.43\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_wrench.png\\\\1.0.1\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_wrench.png\\\\1.0.1\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_yandex_music.png\\\\1.0.10\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_yandex_music.png\\\\1.0.10\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_youtube.png\\\\0.0.4\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_youtube.png\\\\0.0.4\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_youtube.png\\\\1.4.14\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_youtube.png\\\\1.4.14\\\\metadata.json', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_youtube_hc.png\\\\0.0.4\\\\asset', 'browser-profile\\\\Edge Sidebar\\\\2026.2.24.1\\\\edge_hub_apps_youtube_hc.png\\\\0.0.4\\\\metadata.json', 'browser-profile\\\\EdgeArbitration\\\\2026.5.28.1\\\\manifest.json', 'browser-profile\\\\EdgeArbitration\\\\2026.5.28.1\\\\arbitration_priority_list\\\\38.0.1\\\\asset', 'browser-profile\\\\EdgeArbitration\\\\2026.5.28.1\\\\arbitration_priority_list\\\\38.0.1\\\\metadata.json', 'browser-profile\\\\EdgeArbitration\\\\2026.5.28.1\\\\arbitration_priority_list\\\\39.0.3\\\\asset', 'browser-profile\\\\EdgeArbitration\\\\2026.5.28.1\\\\arbitration_priority_list\\\\39.0.3\\\\metadata.json', 'browser-profile\\\\EdgeArbitration\\\\2026.5.28.1\\\\arbitration_priority_list\\\\40.0.2\\\\asset', 'browser-profile\\\\EdgeArbitration\\\\2026.5.28.1\\\\arbitration_priority_list\\\\40.0.2\\\\metadata.json', 'browser-profile\\\\EdgeArbitration\\\\2026.5.28.1\\\\arbitration_priority_list\\\\41.0.0\\\\asset', 'browser-profile\\\\EdgeArbitration\\\\2026.5.28.1\\\\arbitration_priority_list\\\\41.0.0\\\\metadata.json', 'browser-profile\\\\EdgeLanguageDetectionModel\\\\2026.1.30.1\\\\manifest.json', 'browser-profile\\\\EdgeLanguageDetectionModel\\\\2026.1.30.1\\\\model.ftz', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\manifest.json', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\qnn-npu\\\\manifest.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\webgpu-fp16\\\\manifest.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\webgpu-fp16-prerelease\\\\manifest.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\webgpu-fp32\\\\manifest.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\webgpu-fp32-prerelease\\\\manifest.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\qnn-npu\\\\configs\\\\prompt_api.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\qnn-npu\\\\configs\\\\proofreader_api.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\qnn-npu\\\\configs\\\\summarizer_api.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\qnn-npu\\\\configs\\\\writing_assistance_api.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\webgpu-fp16\\\\configs\\\\prompt_api.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\webgpu-fp16\\\\configs\\\\proofreader_api.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\webgpu-fp16\\\\configs\\\\summarizer_api.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\webgpu-fp16\\\\configs\\\\writing_assistance_api.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\webgpu-fp16-prerelease\\\\configs\\\\prompt_api.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\webgpu-fp16-prerelease\\\\configs\\\\proofreader_api.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\webgpu-fp16-prerelease\\\\configs\\\\summarizer_api.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\webgpu-fp16-prerelease\\\\configs\\\\writing_assistance_api.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\webgpu-fp32\\\\configs\\\\prompt_api.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\webgpu-fp32\\\\configs\\\\proofreader_api.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\webgpu-fp32\\\\configs\\\\summarizer_api.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\webgpu-fp32\\\\configs\\\\writing_assistance_api.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\webgpu-fp32-prerelease\\\\configs\\\\prompt_api.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\webgpu-fp32-prerelease\\\\configs\\\\proofreader_api.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\webgpu-fp32-prerelease\\\\configs\\\\summarizer_api.binarypb', 'browser-profile\\\\EdgeOptimizationGuideModelsManifest\\\\2026.11.6.1\\\\variants\\\\webgpu-fp32-prerelease\\\\configs\\\\writing_assistance_api.binarypb', 'browser-profile\\\\GPUPersistentCache\\\\DawnGraphiteCache\\\\23IMHJGI2WIIJ3PDLCHAHUJAGHTLTEBB\\\\cache.db', 'browser-profile\\\\GPUPersistentCache\\\\DawnGraphiteCache\\\\23IMHJGI2WIIJ3PDLCHAHUJAGHTLTEBB\\\\cache.db-wal', 'browser-profile\\\\GPUPersistentCache\\\\DawnGraphiteCache\\\\23IMHJGI2WIIJ3PDLCHAHUJAGHTLTEBB\\\\cache.journal', 'browser-profile\\\\SmartScreen\\\\RemoteData\\\\customSettings', 'browser-profile\\\\SmartScreen\\\\RemoteData\\\\customSettings_F95BA787499AB4FA9EFFF472CE383A14', 'browser-profile\\\\SmartScreen\\\\RemoteData\\\\edgeSettings', 'browser-profile\\\\SmartScreen\\\\RemoteData\\\\edgeSettings_2.0-0', 'output\\\\downloads\\\\sap_oi_filtered.csv']\nHEADERS: ['OI Document', 'Line', 'CreatedAt', 'Sales', 'Customer', 'Status', 'Currency', 'OI Amount']\nSAMPLE ROWS: [{'OI Document': 'OI-1001', 'Line': '10', 'CreatedAt': '2026-09-01 00:00:00', 'Sales': 'Alice Chen', 'Customer': 'Fictional Alpha', 'Status': 'Booked', 'Currency': 'TWD', 'OI Amount': '1000.00'}, {'OI Document': 'OI-1002', 'Line': '10', 'CreatedAt': '2026-09-15 12:00:00', 'Sales': 'Alice Chen', 'Customer': 'Fictional Beta', 'Status': 'Booked', 'Currency': 'USD', 'OI Amount': '50.00'}, {'OI Document': 'OI-1003', 'Line': '10', 'CreatedAt': '2026-09-30 18:00:00', 'Sales': 'Alice Chen', 'Customer': 'Fictional Alpha', 'Status': 'Booked', 'Currency': 'TWD', 'OI Amount': '-100.00'}]\nWROTE: output\\normalized.json\nNORMALIZED COUNT: 12\nSTATUS COUNTS: {'Booked': 12}\nDUPLICATE POLICY: exact duplicate skipped; conflicting duplicate would fail\nCHECKS: passed\n", "files": [{"path": "output/downloads/sap_oi_filtered.csv", "bytes": 1568}, {"path": "output/normalized.json", "bytes": 3267}], "script_path": ".aep-run/run-001/script.py", "workspace_created": false}, "failure": null, "warnings": ["operation_id=operation-4611558c3f004eb29b12c68a8fa41b26"], "handler_invoked": true}], "attempts": [{"step_index": 0, "attempt": 1, "status": "succeeded", "code": null, "handler_invoked": true}]}, "host": null, "failure": null, "recovery": null, "replayed": false}
```

## 模型回合 8

正規化程式執行成功。實際 CSV 欄名符合 SOP；16 筆中去除 1 筆完全重複列、排除 3 筆非 Booked（2 Cancelled、1 Pending），保留 12 筆有效明細，且保留零金額與負數調整。`output/normalized.json` 的型別、唯一鍵、匯率與月份檢查均通過。現在呼叫 `oi__export` 製作含原生 PivotTable 的 Excel，並以其獨立驗收結果為準。

### 工具呼叫 oi__export (call_r7dlhezq5yn0Vx0z53G3b6CC)
```json
{
  "normalized_path": "C:\\Users\\OpenLab\\Documents\\workspace\\aep-harness-reliability-141\\.scratch\\sap-oi-run-3\\output\\normalized.json"
}
```

### 工具結果 call_r7dlhezq5yn0Vx0z53G3b6CC
```json
{"call_id": "call_r7dlhezq5yn0Vx0z53G3b6CC", "name": "oi__export", "decision": null, "capability": null, "workflow": null, "host": {"status": "failed", "data": {"workbook": "C:\\Users\\OpenLab\\Documents\\workspace\\aep-harness-reliability-141\\.scratch\\sap-oi-run-3\\output\\sales-oi-pivot.xlsx", "verification": {"passed": false, "check": "artifact_builder_failed"}}, "failure": {"code": "oi_verification_failed", "message": "Task execution or required validation did not succeed", "retryable": false}}, "failure": null, "recovery": {"recoverable": false, "hint": "Explain this failure to the person and what they can do. Do not repeat the same call unchanged."}, "replayed": false}
```

## 模型回合 9

任務未通過，不能回報完成。

已完成的步驟：

1. 開啟模擬 SAP：`http://127.0.0.1:8766`
2. 核對日期：
   - Start date：`2026-09-01`
   - End date：`2026-10-31`
3. 篩選 Sales：
   - Alice Chen
   - Bob Lin
   - Carol Wu
4. 核對全部 4 頁，共 16 筆資料。
5. 使用瀏覽器 `do=download` 匯出全部篩選資料，未使用 requests/fetch：
   - `output/downloads/sap_oi_filtered.csv`
6. 以 Python 標準函式庫完成正規化：
   - 去除 1 筆完全重複列
   - 排除 2 筆 Cancelled 及 1 筆 Pending
   - 保留零金額與負數 Booked 調整
   - 產生 12 筆有效明細
   - 固定匯率 TWD=1、USD=32
   - 已寫出並重新檢查：
     `output/normalized.json`

最後呼叫 `oi__export` 時失敗。工具回報：

- Excel 路徑：`output/sales-oi-pivot.xlsx`
- 驗收：`passed: false`
- 檢查項目：`artifact_builder_failed`
- 錯誤碼：`oi_verification_failed`
- 不可重試，且沒有提供可修正的具體欄位或資料回饋。

因此目前沒有獨立驗收通過的 Excel；不能宣稱 PivotTable、PivotCache 或來源關係已通過驗收。