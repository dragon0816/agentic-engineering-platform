任務未通過，不能回報完成。

已完成的步驟：

1. 開啟模擬 SAP：`http://127.0.0.1:8766`
2. 核對日期：
   - Start date：`2026-09-01`
   - End date：`2026-10-31`
3. 篩選 Sales：
   - Alice Chen
   - Bob Lin
   - Carol Wu
4. 核對全部 4 頁，共 16 筆資料。
5. 使用瀏覽器 `do=download` 匯出全部篩選資料，未使用 requests/fetch：
   - `output/downloads/sap_oi_filtered.csv`
6. 以 Python 標準函式庫完成正規化：
   - 去除 1 筆完全重複列
   - 排除 2 筆 Cancelled 及 1 筆 Pending
   - 保留零金額與負數 Booked 調整
   - 產生 12 筆有效明細
   - 固定匯率 TWD=1、USD=32
   - 已寫出並重新檢查：
     `output/normalized.json`

最後呼叫 `oi__export` 時失敗。工具回報：

- Excel 路徑：`output/sales-oi-pivot.xlsx`
- 驗收：`passed: false`
- 檢查項目：`artifact_builder_failed`
- 錯誤碼：`oi_verification_failed`
- 不可重試，且沒有提供可修正的具體欄位或資料回饋。

因此目前沒有獨立驗收通過的 Excel；不能宣稱 PivotTable、PivotCache 或來源關係已通過驗收。