from pathlib import Path
import csv, json
from datetime import datetime

workspace = Path('.')
source = workspace / 'output' / 'downloads' / 'sap_oi_filtered.csv'
out = workspace / 'output' / 'normalized.json'
print('INPUT FILES:', [str(p) for p in workspace.rglob('*') if p.is_file()])
with source.open('r', encoding='utf-8-sig', newline='') as f:
    reader = csv.DictReader(f)
    print('HEADERS:', reader.fieldnames)
    sample = []
    for row in reader:
        if len(sample) < 3:
            sample.append(row)
print('SAMPLE ROWS:', sample)

required = ['OI Document','Line','CreatedAt','Sales','Customer','Status','Currency','OI Amount']
if reader.fieldnames != required:
    raise ValueError(f'Unexpected CSV headers: {reader.fieldnames!r}')

rates = {'TWD': 1, 'USD': 32}
records = {}
with source.open('r', encoding='utf-8-sig', newline='') as f:
    for row_num, row in enumerate(csv.DictReader(f), start=2):
        key = (str(row['OI Document']), str(row['Line']))
        created_raw = row['CreatedAt'].strip()
        dt = datetime.strptime(created_raw, '%Y-%m-%d %H:%M:%S')
        currency = row['Currency'].strip()
        if currency not in rates:
            raise ValueError(f'Unsupported currency at CSV row {row_num}: {currency}')
        amount = float(row['OI Amount'].replace(',', '').strip())
        canonical = (key, created_raw, row['Sales'], row['Customer'], row['Status'], currency, amount)
        if key in records:
            if records[key]['canonical'] != canonical:
                raise ValueError(f'Conflicting duplicate for OI Document + Line: {key}')
            continue
        records[key] = {'canonical': canonical, 'row': row, 'dt': dt, 'amount': amount}

normalized = []
for item in records.values():
    row = item['row']
    if row['Status'].strip() != 'Booked':
        continue
    currency = row['Currency'].strip()
    normalized.append({
        'document': str(row['OI Document']),
        'line': str(row['Line']),
        'created_at': item['dt'].strftime('%Y-%m-%d %H:%M:%S'),
        'sales': row['Sales'],
        'customer': row['Customer'],
        'status': row['Status'],
        'currency': currency,
        'amount': item['amount'],
        'fx': rates[currency],
        'month': item['dt'].strftime('%Y-%m'),
    })
normalized.sort(key=lambda r: (r['created_at'], r['document'], r['line']))
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(normalized, ensure_ascii=False, indent=2), encoding='utf-8')

# Independent local output checks required by the task.
reloaded = json.loads(out.read_text(encoding='utf-8'))
assert isinstance(reloaded, list)
assert len(reloaded) == 12
assert len({(r['document'], r['line']) for r in reloaded}) == len(reloaded)
assert all(r['status'] == 'Booked' for r in reloaded)
assert any(r['amount'] == 0 for r in reloaded)
assert any(r['amount'] < 0 for r in reloaded)
assert all(r['currency'] in rates and r['fx'] == rates[r['currency']] for r in reloaded)
assert all(datetime.strptime(r['created_at'], '%Y-%m-%d %H:%M:%S').strftime('%Y-%m') == r['month'] for r in reloaded)
print('WROTE:', out)
print('NORMALIZED COUNT:', len(reloaded))
print('STATUS COUNTS:', {s: sum(r['status'] == s for r in reloaded) for s in sorted({r['status'] for r in reloaded})})
print('DUPLICATE POLICY: exact duplicate skipped; conflicting duplicate would fail')
print('CHECKS: passed')