已完成受控 SAP OI 匯出任務，所有操作均限於指定工作目錄及本機模擬 SAP。

### 操作紀錄

1. 開啟模擬 SAP：`http://127.0.0.1:8766`
2. 核對並套用篩選：
   - Start date：`2026-09-01`
   - End date：`2026-10-31`
   - Sales：`Alice Chen,Bob Lin,Carol Wu`
3. 確認結果共 16 筆、4 頁，每頁 5 筆；已查看全部頁面。
4. 使用瀏覽器 `do=download` 下載全部篩選資料：
   - `output/downloads/filtered_oi.csv`
5. 使用 Python 標準函式庫完成正規化：
   - 唯一明細鍵：`OI Document + Line`
   - 15 個唯一來源鍵
   - 完全相同重複列去除 1 筆
   - `Booked` 有效明細：12 筆
   - `Cancelled`、`Pending` 排除：3 筆
   - 零金額及負數調整均保留
   - 匯率：TWD→TWD = 1、USD→TWD = 32
   - 輸出：`output/normalized.json`

### Excel 產出

已製作：

`C:\Users\OpenLab\Documents\workspace\aep-harness-reliability-141\.scratch\sap-oi-run-5\output\sales-oi-pivot.xlsx`

內容包括：

- `OI Pivot`：Sales × Month 的 OI TWD 加總及總計
- `OI Data`：12 筆有效明細、來源與換算資料
- OI TWD 以 Excel 公式計算
- 原生 PivotTable、PivotCache definition/records 及來源關係

### 獨立驗收結果

- 驗收通過：`passed: true`
- 明細筆數：12
- OI TWD 總計：`13,580`
- 原生 Pivot 解析：通過
- Cache 與來源資料一致：通過
- Excel 桌面刷新：`unverified_not_installed`（環境未安裝 Microsoft Excel）
- 公式快取：為計算快照，尚未由 Excel Desktop 重新計算

任務已完成，且獨立驗收已通過。