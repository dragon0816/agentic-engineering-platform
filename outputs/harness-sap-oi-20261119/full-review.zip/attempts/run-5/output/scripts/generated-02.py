from pathlib import Path
import csv, json
from datetime import datetime

src = Path('output/downloads/filtered_oi.csv')
out = Path('output/normalized.json')
expected = ['OI Document','Line','CreatedAt','Sales','Customer','Status','Currency','OI Amount']
allowed_sales = {'Alice Chen','Bob Lin','Carol Wu'}
fx_map = {'TWD': 1.0, 'USD': 32.0}
start = datetime.fromisoformat('2026-09-01 00:00:00')
end = datetime.fromisoformat('2026-10-31 23:59:59')
seen = {}
valid = []
with src.open('r', encoding='utf-8-sig', newline='') as f:
    reader = csv.DictReader(f)
    if reader.fieldnames != expected:
        raise ValueError(f'Unexpected headers: {reader.fieldnames!r}')
    for rownum, r in enumerate(reader, 2):
        key = (r['OI Document'], r['Line'])
        canonical = tuple(r[k] for k in expected)
        if key in seen:
            if seen[key] != canonical:
                raise ValueError(f'Conflicting duplicate key at CSV row {rownum}: {key}')
            continue
        seen[key] = canonical
        created = datetime.strptime(r['CreatedAt'], '%Y-%m-%d %H:%M:%S')
        if not (start <= created <= end):
            raise ValueError(f'Out-of-range row: {key}')
        if r['Sales'] not in allowed_sales:
            raise ValueError(f'Unexpected Sales: {r["Sales"]}')
        if r['Status'] != 'Booked':
            continue
        if r['Currency'] not in fx_map:
            raise ValueError(f'Unexpected currency: {r["Currency"]}')
        amount = float(r['OI Amount'])
        valid.append({
            'document': r['OI Document'],
            'line': r['Line'],
            'created_at': created.strftime('%Y-%m-%d %H:%M:%S'),
            'sales': r['Sales'],
            'customer': r['Customer'],
            'status': r['Status'],
            'currency': r['Currency'],
            'amount': amount,
            'fx': fx_map[r['Currency']],
            'month': created.strftime('%Y-%m'),
        })
valid.sort(key=lambda x: (x['created_at'], x['document'], x['line']))
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(valid, ensure_ascii=False, indent=2), encoding='utf-8')
# independent local output check
loaded = json.loads(out.read_text(encoding='utf-8'))
assert len(loaded) == 12
assert all(set(x) == {'document','line','created_at','sales','customer','status','currency','amount','fx','month'} for x in loaded)
assert all(isinstance(x['line'], str) and isinstance(x['amount'], (int,float)) and isinstance(x['fx'], (int,float)) for x in loaded)
assert all(x['status'] == 'Booked' and x['currency'] in fx_map for x in loaded)
print('SOURCE_ROWS_UNIQUE', len(seen))
print('VALID_BOOKED_ROWS', len(loaded))
print('EXCLUDED_STATUS_ROWS', len(seen)-len(loaded))
print('OUTPUT', out, 'BYTES', out.stat().st_size)
print('MONTH_SALES_COUNTS', sorted((x['sales'], x['month']) for x in loaded))