from pathlib import Path
import csv
base = Path('output/downloads')
files = sorted(base.iterdir())
print('FILES:', [str(p) for p in files])
for p in files:
    print('FILE', p.name, 'SIZE', p.stat().st_size)
    with p.open('r', encoding='utf-8-sig', newline='') as f:
        r = csv.reader(f)
        rows = list(r)
    print('ROWS', len(rows), 'HEADER', rows[0] if rows else None)
    print('SAMPLES', rows[1:4])