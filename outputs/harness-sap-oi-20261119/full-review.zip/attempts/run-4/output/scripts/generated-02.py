from pathlib import Path
import csv, json
root=Path('.')
files=sorted((root/'output'/'downloads').glob('*.csv'))
print('download files:', [str(p) for p in files])
source=files[0]
with source.open('r',encoding='utf-8-sig',newline='') as f:
 r=csv.DictReader(f); print('headers:',r.fieldnames); print('sample rows:',[row for _,row in zip(range(3),r)])
required=['OI Document','Line','CreatedAt','Sales','Customer','Status','Currency','OI Amount']
seen={}
with source.open('r',encoding='utf-8-sig',newline='') as f:
 r=csv.DictReader(f)
 if r.fieldnames!=required: raise ValueError(r.fieldnames)
 for row in r:
  key=(str(row['OI Document']),str(row['Line']))
  if key in seen and row!=seen[key]: raise ValueError(f'Conflicting duplicate key {key}')
  seen.setdefault(key,dict(row))
out=[]
for row in seen.values():
 if row['Status']!='Booked': continue
 if row['Currency'] not in ('TWD','USD'): raise ValueError(row['Currency'])
 created=row['CreatedAt']; amount=float(row['OI Amount'].replace(',',''))
 out.append({'document':str(row['OI Document']),'line':str(row['Line']),'created_at':created,'sales':row['Sales'],'customer':row['Customer'],'status':'Booked','currency':row['Currency'],'amount':amount,'fx':1.0 if row['Currency']=='TWD' else 32.0,'month':created[:7]})
out.sort(key=lambda x:(x['created_at'],x['document'],x['line']))
path=root/'output'/'normalized.json'; path.parent.mkdir(exist_ok=True)
with path.open('w',encoding='utf-8') as f: json.dump(out,f,ensure_ascii=False,indent=2); f.write('\n')
with path.open(encoding='utf-8') as f: check=json.load(f)
assert len(check)==12
assert all(isinstance(x['document'],str) and isinstance(x['line'],str) for x in check)
assert all(isinstance(x['amount'],(int,float)) and isinstance(x['fx'],(int,float)) for x in check)
assert all(x['status']=='Booked' and x['currency'] in ('TWD','USD') and x['month']==x['created_at'][:7] for x in check)
print('unique source rows:',len(seen)); print('normalized Booked rows:',len(out)); print('output:',path); print('output check: passed')