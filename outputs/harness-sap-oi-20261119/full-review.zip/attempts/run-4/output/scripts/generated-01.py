from pathlib import Path
import csv, json

root = Path('.')
files = sorted((root / 'output' / 'downloads').glob('*'))
print('download files:', [str(p) for p in files])
if not files:
    raise FileNotFoundError('No browser download found')
source = files[0]
with source.open('r', encoding='utf-8-sig', newline='') as f:
    reader = csv.DictReader(f)
    print('headers:', reader.fieldnames)
    sample = []
    for i, row in enumerate(reader):
        if i < 3:
            sample.append(row)
    print('sample rows:', sample)

# Complete normalization, preserving source file unchanged.
source = root / 'output' / 'downloads' / 'oi_filtered.csv'
if not source.exists():
    candidates = sorted((root / 'output' / 'downloads').glob('*.csv'))
    if len(candidates) != 1:
        raise FileNotFoundError('Expected exactly one downloaded CSV')
    source = candidates[0]

required = ['OI Document', 'Line', 'CreatedAt', 'Sales', 'Customer', 'Status', 'Currency', 'OI Amount']
seen = {}
with source.open('r', encoding='utf-8-sig', newline='') as f:
    reader = csv.DictReader(f)
    if reader.fieldnames != required:
        raise ValueError(f'Unexpected headers: {reader.fieldnames!r}')
    for row in reader:
        key = (str(row['OI Document']), str(row['Line']))
        if key in seen:
            if row != seen[key]:
                raise ValueError(f'Conflicting duplicate key: {key}')
            continue
        seen[key] = dict(row)

out = []
for row in seen.values():
    if row['Status'] != 'Booked':
        continue
    currency = row['Currency']
    if currency not in ('TWD', 'USD'):
        raise ValueError(f'Unsupported currency: {currency}')
    created = row['CreatedAt']
    # ISO-like source timestamps are already Asia/Taipei local timestamps per SOP.
    if len(created) != 19 or created[4] != '-' or created[7] != '-' or created[10] != ' ':
        raise ValueError(f'Invalid CreatedAt: {created}')
    amount = float(row['OI Amount'].replace(',', ''))
    fx = 1.0 if currency == 'TWD' else 32.0
    out.append({
        'document': str(row['OI Document']),
        'line': str(row['Line']),
        'created_at': created,
        'sales': row['Sales'],
        'customer': row['Customer'],
        'status': row['Status'],
        'currency': currency,
        'amount': amount,
        'fx': fx,
        'month': created[:7],
    })
out.sort(key=lambda r: (r['created_at'], r['document'], r['line']))
normalized = root / 'output' / 'normalized.json'
normalized.parent.mkdir(parents=True, exist_ok=True)
with normalized.open('w', encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
    f.write('\n')
print('unique source rows:', len(seen))
print('normalized Booked rows:', len(out))
print('output:', normalized)

# Independent output check required by task.
with normalized.open('r', encoding='utf-8') as f:
    check = json.load(f)
assert len(check) == len(out)
assert all(isinstance(r['document'], str) and isinstance(r['line'], str) for r in check)
assert all(isinstance(r['amount'], (int, float)) and isinstance(r['fx'], (int, float)) for r in check)
assert all(r['status'] == 'Booked' and r['currency'] in ('TWD', 'USD') for r in check)
assert all(r['month'] == r['created_at'][:7] for r in check)
print('output check: passed; source unchanged and normalized schema valid')