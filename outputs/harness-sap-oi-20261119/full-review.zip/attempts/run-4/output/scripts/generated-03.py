from pathlib import Path
from zipfile import ZipFile
import re
p=Path('output/sales-oi-pivot.xlsx')
print('exists:',p.exists(),'bytes:',p.stat().st_size if p.exists() else None)
if not p.exists(): raise FileNotFoundError(p)
with ZipFile(p) as z:
 names=z.namelist()
 print('zip entries:', names)
 for n in names:
  if n.endswith('.xml') and ('sheet' in n or 'pivot' in n or 'cache' in n or 'workbook' in n):
   data=z.read(n).decode('utf-8','replace')
   print('\nFILE',n,'chars',len(data),'snippet',data[:500])