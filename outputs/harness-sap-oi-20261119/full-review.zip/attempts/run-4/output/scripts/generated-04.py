from pathlib import Path
for name in ['output/saved-cell-snapshot.json','output/artifact-read-check.json']:
 p=Path(name); print('\n',name); print(p.read_text(encoding='utf-8')[:10000])