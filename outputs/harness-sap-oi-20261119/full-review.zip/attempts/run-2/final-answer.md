任務未完成，不能回報驗收通過。已實際完成的步驟如下：

1. **瀏覽器操作**
   - 開啟 `http://127.0.0.1:8766`，確認頁面為「模擬 SAP OI」。
   - 核對日期預設值：
     - Start date：`2026-09-01`
     - End date：`2026-10-31`
   - 填入 Sales：`Alice Chen,Bob Lin,Carol Wu`
   - 執行搜尋，結果顯示 **16 筆**，共 4 頁，每頁 5 筆。
   - 已逐頁操作至第 4 頁，未只處理第一頁。
   - 使用瀏覽器的 **Export all filtered CSV** 下載：
     - `output/downloads/oi_filtered.csv`
     - 原始 CSV 未被修改。

2. **CSV 正規化**
   - 使用 Python 標準函式庫處理瀏覽器下載的 CSV，沒有使用 requests、fetch 或直接讀取網站 fixture。
   - 原始 CSV 共 16 筆。
   - 已檢查 `OI Document + Line` 重複鍵及衝突。
   - 排除非 `Booked` 狀態，保留負數與零金額。
   - 套用：
     - TWD → TWD：`1`
     - USD → TWD：`32`
   - 產生 12 筆有效明細，寫入：
     - `output/normalized.json`
   - 已重新開啟輸出檔檢查欄位、型別、狀態、幣別及月份。
   - 產出程式：
     - `output/normalize_oi.py`

3. **Excel 匯出及獨立驗收**
   - 已呼叫 `oi__export`。
   - 工具產生：
     - `output/sales-oi-pivot.xlsx`
   - 但獨立驗收結果為：
     - `passed: false`
     - `check: artifact_builder_failed`
   - 進一步檢查發現該 XLSX 僅包含一般工作表及表格部件，沒有必要的：
     - PivotTable parts
     - PivotCache definition
     - PivotCache records
     - 有效 PivotTable 關聯

因此目前的 Excel **不符合 SOP 第 8、9 步**，尤其不是可驗收的原生 Excel PivotTable。由於 `oi__export` 回報不可重試的建構器失敗，且目前沒有可用的修正參數或替代 PivotTable 建構工具，我不能虛稱已完成。