from pathlib import Path
p=Path('output/sales-oi-pivot.xlsx.inspect.ndjson')
print(p.read_text(encoding='utf-8')[:20000])