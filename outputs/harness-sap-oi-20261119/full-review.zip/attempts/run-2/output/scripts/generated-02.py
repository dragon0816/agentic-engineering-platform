from pathlib import Path
import json, zipfile
root=Path('.')
np=root/'output'/'normalized.json'
wb=root/'output'/'sales-oi-pivot.xlsx'
print('FILES:', [(str(p), p.stat().st_size) for p in [np, wb] if p.exists()])
data=json.loads(np.read_text(encoding='utf-8'))
print('NORMALIZED COUNT:', len(data))
print('NORMALIZED KEYS:', sorted(data[0].keys()) if data else [])
print('ROWS:', data)
if wb.exists():
    with zipfile.ZipFile(wb) as z:
        names=z.namelist()
        print('ZIP PARTS:', names)
        print('PIVOT PARTS:', [n for n in names if 'pivot' in n.lower()])
        print('CACHE PARTS:', [n for n in names if 'cache' in n.lower()])
        bad=[n for n in names if n.endswith('.xml') and b'error' in z.read(n).lower()]
        print('XML ERROR MARKERS:', bad)