from pathlib import Path
import csv, json

root = Path('.')
files = sorted((root / 'output' / 'downloads').glob('*.csv'))
print('INPUT FILES:', [str(p) for p in files])
if not files:
    raise FileNotFoundError('No browser-downloaded CSV found')
source = files[0]
with source.open('r', encoding='utf-8-sig', newline='') as f:
    reader = csv.DictReader(f)
    print('HEADERS:', reader.fieldnames)
    rows = list(reader)
print('ROW COUNT:', len(rows))
print('SAMPLE ROWS:', rows[:2])

required = ['OI Document','Line','CreatedAt','Sales','Customer','Status','Currency','OI Amount']
if reader.fieldnames != required:
    raise ValueError(f'Unexpected headers: {reader.fieldnames}')
seen = {}
for r in rows:
    key = (r['OI Document'], r['Line'])
    normalized_content = tuple(r[h] for h in required)
    if key in seen:
        if seen[key] != normalized_content:
            raise ValueError(f'Conflicting duplicate key: {key}')
        continue
    seen[key] = normalized_content

out = []
fx_map = {'TWD': 1.0, 'USD': 32.0}
for r in rows:
    key = (r['OI Document'], r['Line'])
    if seen.get(key) != tuple(r[h] for h in required):
        continue
    if r['Status'] != 'Booked':
        continue
    if r['Currency'] not in fx_map:
        raise ValueError(f'Unsupported currency: {r["Currency"]}')
    created = r['CreatedAt']
    if len(created) < 7:
        raise ValueError(f'Invalid CreatedAt: {created}')
    amount = float(r['OI Amount'].replace(',', '').strip())
    out.append({
        'document': r['OI Document'],
        'line': str(r['Line']),
        'created_at': created,
        'sales': r['Sales'],
        'customer': r['Customer'],
        'status': r['Status'],
        'currency': r['Currency'],
        'amount': amount,
        'fx': fx_map[r['Currency']],
        'month': created[:7],
    })
# Ensure deduplication in emitted rows and stable ordering.
unique = {(x['document'], x['line']): x for x in out}
out = sorted(unique.values(), key=lambda x: (x['created_at'], x['document'], x['line']))
out_path = root / 'output' / 'normalized.json'
out_path.parent.mkdir(parents=True, exist_ok=True)
out_path.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding='utf-8')
# Save the exact reusable processing source as an audit artifact.
script_path = root / 'output' / 'normalize_oi.py'
script_path.write_text(Path(__file__).read_text(encoding='utf-8') if '__file__' in globals() else '# Source supplied to coding__run; see conversation.', encoding='utf-8')

# Independent local checks against the saved JSON.
loaded = json.loads(out_path.read_text(encoding='utf-8'))
assert len(loaded) == len(out)
assert all(isinstance(x['line'], str) and isinstance(x['amount'], (int, float)) and isinstance(x['fx'], (int, float)) for x in loaded)
assert all(x['status'] == 'Booked' and x['currency'] in fx_map and x['month'] == x['created_at'][:7] for x in loaded)
print('VALID BOOKED ROWS:', len(loaded))
print('NORMALIZED PATH:', out_path.resolve())
print('NORMALIZED SAMPLE:', loaded[:2])
print('CHECKS: source unchanged, duplicate keys checked, conflicts rejected, saved JSON reopened and types/status/currency/month validated')